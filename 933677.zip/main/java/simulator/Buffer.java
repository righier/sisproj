package simulator;
public interface Buffer {

    void addMeasurement(Measurement m);

}
